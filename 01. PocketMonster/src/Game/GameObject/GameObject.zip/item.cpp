#include "stdafx.h"
#include "item.h"

bool Item::init()
{

	return true;
}

void Item::update(float _deltaTime)
{
}

void Item::render(HDC hdc)
{
}

void Item::afterRender(HDC hdc)
{
}

void Item::debugRender(HDC hdc)
{
}
